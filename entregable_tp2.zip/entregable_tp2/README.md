
## Instrucciones:

### Compilación
cmake CMakeLists.txt

make

### Ejecución
Ejecutable: tp2

Parámetros:
- Nombre del archivo .txt a ejecutar desde directorio examples
- Nro de iteraciones para método de la potencia
- Tolerancia para convergencia del método de la potencia

Resultados: se escriben a un archivo del mismo nombre del input, en el directorio results

### Ejemplo:
./tp2 karateclub 10000 e^-6

## Link al informe:
https://www.overleaf.com/project/63361ede618f8b4e321c2715
