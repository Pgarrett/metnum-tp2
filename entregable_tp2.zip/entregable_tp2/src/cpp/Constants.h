//
// Created by Fernando N. Frassia on 10/1/22.
//

namespace Constants {
    constexpr int powerMethodIterations {100000};
    constexpr double powerMethodEpsilon {0.0000000001};
}