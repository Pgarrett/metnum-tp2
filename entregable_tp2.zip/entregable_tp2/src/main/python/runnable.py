import exercise1 as ex1
import exercise2 as ex2
import exercise3 as ex3

ex1.run()
ex2.run()
ex3.run()